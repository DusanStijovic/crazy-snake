#ifndef _crazy_snake_h 
#define _crazy_snake_h
//Print logo of the game.
void crazy_snake(int, int);
#endif
