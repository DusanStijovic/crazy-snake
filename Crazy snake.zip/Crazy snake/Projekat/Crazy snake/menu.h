#ifndef _manu_h_
#define _manu_h_
//Print start menu. 
void print_menu(WINDOW*, int, int, int);
int open_menu(int, int);
#endif