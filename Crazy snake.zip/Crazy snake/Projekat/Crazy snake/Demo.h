#ifndef _Demo_h
#define _Demo_h
#include "gameplay.h"
//Demonstration of game.
void demo(short **, Header *, Fruit *, int* score, Options *options);
void print_nopath_win();
#endif