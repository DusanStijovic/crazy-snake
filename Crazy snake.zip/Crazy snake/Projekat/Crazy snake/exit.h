#ifndef _exit_h_
#define _exit_h_
#include <curses.h>
//Exit window.

void print_exit(WINDOW*, int);
void open_exit();
#endif
