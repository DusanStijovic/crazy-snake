#ifndef _loading2_h_
#define _loading_h_
void loading2_part2(WINDOW*, int, int, int);
void loading2(int, int);
#endif