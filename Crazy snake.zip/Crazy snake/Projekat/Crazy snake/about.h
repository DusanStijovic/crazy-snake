#ifndef _about_h_
#define _about_h_ 
//Shows information about the game.
void open_about(void);
#endif