#ifndef _help_h_
#define _help_h_
void print_help_next(WINDOW*);
void open_help_next(void);
void print_help(WINDOW*);
void open_help(void);
#endif 